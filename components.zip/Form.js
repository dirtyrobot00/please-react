import React, {Component} from 'react';
import './Form.css';



class Form extends Component {

    render() {
        const {onClickNext, onClickPrev} = this.props;
        return (
            <div>
            <br></br>
            <button className = {'create-button'} onClick = {onClickPrev} > PREVIOUS </button>
            <button className = {'create-button'} onClick = {onClickNext}> NEXT </button>
            </div>
        )

    }

}

export default Form;