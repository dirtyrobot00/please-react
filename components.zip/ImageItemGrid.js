import React, {Component} from 'react';
import './ImgaeItemGrid.css';
import ImageItem from './ImageItem';

class ImageItemGrid extends Component {

    render() {

        return(
        <ImageItem car = {this.state.car[0]}></ImageItem>
        );

    }

}