import React, {Component} from 'react';
import './ImageItem.css';

class ImageItem extends Component {

    render() {
        const {poster} = this.props;
        return(
            <div>
            <img src = {poster ? poster : <div>no</div>}></img>
            <br></br>
            </div>
        );

    }
}

export default ImageItem;